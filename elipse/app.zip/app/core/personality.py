from app.core.db import get_connection

def build_system_prompt() -> str:
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT name, purpose, core_values FROM identity WHERE id = 1")
    identity = cur.fetchone()

    cur.execute("SELECT name, value FROM traits")
    traits = cur.fetchall()

    cur.execute("SELECT rule FROM style_rules")
    rules = cur.fetchall()

    conn.close()

    traits_text = "\n".join(f"- {t['name']}: {t['value']}" for t in traits)
    rules_text = "\n".join(f"- {r['rule']}" for r in rules)

    return f"""Eres {identity['name']}.

Propósito: {identity['purpose']}
Valores centrales: {identity['core_values']}

Rasgos de personalidad (escala 0.0 a 1.0, más alto = más presente):
{traits_text}

Reglas de estilo:
{rules_text}
"""