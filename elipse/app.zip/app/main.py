from fastapi import FastAPI
from pydantic import BaseModel
import ollama
from app.config import settings
from app.core.db import get_connection, init_db
from app.core.seed_personality import seed
from app.core.personality import build_system_prompt

app = FastAPI(title=settings.app_name)

init_db()
seed()

class ChatRequest(BaseModel):
    message: str

def save_message(role: str, content: str):
    conn = get_connection()
    conn.execute("INSERT INTO messages (role, content) VALUES (?, ?)", (role, content))
    conn.commit()
    conn.close()

@app.get("/v1/status")
def status():
    return {"status": "ok", "name": settings.app_name, "model": settings.ollama_model}

@app.post("/v1/chat")
def chat(request: ChatRequest):
    system_prompt = build_system_prompt()
    save_message("user", request.message)

    response = ollama.chat(
        model=settings.ollama_model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": request.message}
        ]
    )
    reply = response["message"]["content"]
    save_message("assistant", reply)
    return {"reply": reply}